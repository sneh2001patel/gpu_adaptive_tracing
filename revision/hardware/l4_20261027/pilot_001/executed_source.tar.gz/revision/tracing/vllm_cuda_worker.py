"""vLLM 0.10.2 V1 worker: execute capture APIs in the actual CUDA owner.

Imported only by the GPU serving environment, never by CPU test discovery.
"""
import json
import os
from pathlib import Path
import time

import torch
from vllm.v1.worker.gpu_worker import Worker


def atomic_json(path, record):
    temporary = path.with_suffix('.pending')
    temporary.write_text(json.dumps(record, allow_nan=False) + '\n')
    temporary.replace(path)


class CudaCaptureWorker(Worker):
    def init_device(self):
        super().init_device()
        directory = Path(os.environ['REVISION_SESSION_DIR'])
        properties = torch.cuda.get_device_properties(self.device)
        device_uuid = str(properties.uuid)
        if not device_uuid.startswith('GPU-'):
            device_uuid = 'GPU-' + device_uuid
        self._revision_uuid = device_uuid
        atomic_json(directory / f'worker-{os.getpid()}.json', dict(pid=os.getpid(),
            device_uuid=device_uuid, device_index=torch.cuda.current_device(),
            clock_domain=os.environ['REVISION_CLOCK_DOMAIN'], ready_at_ns=time.monotonic_ns()))

    def profile(self, is_start=True):
        directory = Path(os.environ['REVISION_SESSION_DIR'])
        command = json.loads((directory / 'control.json').read_text())
        before = time.monotonic_ns()
        torch.cuda.synchronize()
        api = torch.cuda.cudart().cudaProfilerStart if is_start else torch.cuda.cudart().cudaProfilerStop
        result = api()
        if int(result) != 0:
            raise RuntimeError(f'CUDA profiler API returned {result}')
        after = time.monotonic_ns()
        action = 'start' if is_start else 'stop'
        atomic_json(directory / f'{command["token"]}-{os.getpid()}-{action}.json', dict(
            capture_id=command['capture_id'], token=command['token'], ordinal=command['ordinal'],
            action=action, source='cuda_worker_api', pid=os.getpid(), device_uuid=self._revision_uuid,
            requested_at_ns=before, returned_at_ns=after, cuda_return_code=0,
            clock_domain=os.environ['REVISION_CLOCK_DOMAIN']))
